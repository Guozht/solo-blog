title: DUILib  界面库的使用
date: '2019-04-14 13:46:34'
updated: '2019-04-15 00:33:31'
tags: [Duilib]
permalink: /articles/2019/04/14/1555220792476.html
---
![](https://img.hacpai.com/bing/20181103.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

# DUILib 界面库的使用
## 注册控件
- 控件命名方式<br/>
以CxxxxUI格式命名控件<br/>
原因：在CDlgBuilder中解析xml创建控件时代码如下
```
CDuiString strClass;
strClass.Format(_T("C%sUI"), pstrClass);
pControl = dynamic_cast<CControlUI*>(CControlFactory::GetInstance()->CreateControl(strClass));
```
另外控件需要实现 CreateControl 函数 可以在头文件中使用```DECLARE_DUICONTROL(CxxxxUI)```
在CPP中使用```IMPLEMENT_DUICONTROL(CxxxxUI)```<br/>
下面为两个宏定义的实现
```
#define DECLARE_DUICONTROL(class_name)\
public:\
	static CControlUI* CreateControl();

#define IMPLEMENT_DUICONTROL(class_name)\
	CControlUI* class_name::CreateControl()\
	{ return new class_name; }
```
- xml反射控件<br/>
在CControlFactory类构造函数中注册<br/>
形式为 ```INNER_REGISTER_DUICONTROL(CxxxxUI);```<br/>
或者在其他地方 ``` REGIST_DUICONTROL(CxxxxUI)```<br/>
下面为两个宏的定义
```
#define REGIST_DUICONTROL(class_name)\
	CControlFactory::GetInstance()->RegistControl(_T(#class_name), (CreateClass)class_name::CreateControl);
#define INNER_REGISTER_DUICONTROL(class_name)\
	RegistControl(_T(#class_name), (CreateClass)class_name::CreateControl);
```
此时就可以在xml中引用该控件
- xml反射控件属性<br/>
在控件类重写SetAttribute函数<br/>
```
if( node.HasAttributes() ) {
  TCHAR szValue[500] = { 0 };
  SIZE_T cchLen = lengthof(szValue) - 1;
  // Set ordinary attributes
  int nAttributes = node.GetAttributeCount();
  for( int i = 0; i < nAttributes; i++ ) {
    pControl->SetAttribute(node.GetAttributeName(i), node.GetAttributeValue(i));
  }
}
```
- 在 UIDefine.h中 注册控件名称的宏定义<br/>
如：```#define  DUI_CTR_HORIZONTALLAYOUT (_T("HorizontalLayout"))```
- 在UILib.h中 添加控件的头文件<br/>
