title: Linux Centos7 安装libudev
date: '2019-04-16 08:57:44'
updated: '2019-04-16 08:57:44'
tags: [Linux, libudev]
permalink: /articles/2019/04/16/1555405064301.html
---
最近在centos 7.2上面遇到这样的编译错误

cannot find file libudev.h



在ubuntu 上面直接由 apt-get install libudev-dev 可以搞定。但是 centos上面没有这种类似的包。

这种情况下：



sudo yum provides */libudev.h

可以找到相应的包来解决这个问题。
--------------------- 
作者：jiang__jiang 
来源：CSDN 
原文：https://blog.csdn.net/jiang__jiang/article/details/54692328 