title: Nginx 反向代理多应用
date: '2019-04-15 17:20:43'
updated: '2019-04-20 08:01:06'
tags: [Nginx, 反向代理]
permalink: /articles/2019/04/15/1555320043296.html
---
![](https://img.hacpai.com/bing/20190115.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

# Nginx 反向代理多应用
## config 配置
参考 https://www.jb51.net/article/127501.htm